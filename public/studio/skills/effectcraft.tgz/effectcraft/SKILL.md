---
name: effectcraft
description: Piloter EffectCraft (alternative open source à After Effects, app native Mac/Windows, projets .ecproj) depuis Claude Code pour créer des compositions, des textes animés, de vrais effets (Turbulent Displace, Optics Compensation, flou, masques) et les rendre en MP4 60 i/s. Remplace le skill after-effects de la formation (After Effects n'est PAS utilisé). À charger dès qu'on parle d'EffectCraft, d'effets pro, de « vague par lettre », de logo qui remplit l'écran, ou de l'exercice « texte en vague + logo ».
---

# EffectCraft piloté par Claude Code

EffectCraft (v0.4.0, app dans /Applications) reproduit le modèle de scripts d'After Effects : mêmes objets (`app.project`, `CompItem`, `Layer`, `Property`),
mêmes **matchName** (`ADBE Turbulent Displace`…), 306 effets, même file d'attente de rendu. Les scripts de la formation
s'adaptent donc presque tels quels. Claude écrit un script `.jsx`, `ec.py` l'envoie à l'app par un canal local
(`engine.execute` → `script.run`, TCP 127.0.0.1:9877) et affiche le journal. L'élève n'a rien à manipuler : il regarde.

## 1. Mise en place (une seule fois)
L'élève n'est pas développeur : une étape à la fois, jamais de terminal.
1. **Installer l'app** : ouvrir `~/Downloads/effectcraft-<version>-macos-universal.dmg`, glisser EffectCraft dans
   **Applications**. (Elle tourne aussi depuis le disque monté, mais ça disparaît à l'éjection.)
2. **Test** : `python3 ~/.claude/skills/effectcraft/scripts/ec.py ~/.claude/skills/effectcraft/scripts/exemple.jsx`
   → affiche `rendu : /tmp/exemple_claude.mp4` (texte rouge qui se déforme). L'ouvrir (`open`), puis dire que c'est branché.
3. `ec.py` lance lui-même EffectCraft avec `--control 9877` s'il ne répond pas. Si une instance est déjà ouverte SANS
   le canal : la quitter (Cmd + Q) et laisser `ec.py` relancer. Le port n'a pas d'authentification : ne l'ouvrir que le temps du travail.
4. Aucune autorisation Mac, aucune préférence à cocher (contrairement à After Effects).

## 2. Lancer un script
```bash
python3 ~/.claude/skills/effectcraft/scripts/ec.py /chemin/absolu/mon_script.jsx
```
- `lib.js` est ajouté après ton script (pas d'`#include`) : `j(msg)` (journal), `effet(calque, matchName)`,
  `reglage(fx, matchName)`, `cles(prop, comp, [[image, valeur], …])` (en IMAGES), `calqueEffets(comp)`,
  `rendre(comp, chemin_avec_extension, modele)`.
- Sortie : journal (`$.writeln`), valeur de la dernière expression (`=> …`), ou `ERREUR script : … (ligne N)`.
  Contrairement à After Effects : **pas de fenêtre d'erreur modale**, les erreurs reviennent proprement avec leur ligne.
- Appel brut d'une commande du moteur : `ec.py --methode commands '{"filter":"layer"}'` (liste), ou
  `ec.py --methode execute '{"command":"comp.new","params":{"name":"A"}}'`. Décrire une commande :
  `{"command":"command.describe","params":{"command":"comp.new"}}`.
- Modèle de script : tout dans `try { … } catch (e) { j("ERREUR : " + e + " (ligne " + e.line + ")"); }`, entouré de
  `app.beginUndoGroup("nom") … app.endUndoGroup()` (une erreur garde les modifs déjà faites).
- **Finir par** `comp.openInViewer(); comp.time = …;` pour que l'élève voie la comp dans la fenêtre. Enregistrer :
  `app.project.save(new File("/chemin/projet.ecproj"))` (sinon le travail n'existe qu'en mémoire).
- Ménage : ne supprimer que les compositions créées par le script en cours (par leur nom).

## 3. Différences avec After Effects (lire avant d'écrire un script)
- **Interface et noms de modèles en ANGLAIS** : `"H.264 - Match Render Settings - 15 Mbps"`, `"H.264"`, `"ProRes"`,
  `"PNG Sequence"`, `"JPEG Sequence"`, `"TIFF Sequence"`, `"OpenEXR Sequence"`, `"GIF"`. Si le modèle est déjà celui par
  défaut, `applyTemplate` répond « nothing to change » (déjà géré par `rendre`).
- **L'extension n'est PAS ajoutée** : donner `.mp4` / `.mov` dans le chemin de rendu. Sans elle le fichier n'a pas d'extension.
- **Viser par matchName** (listes : `references/effets.tsv` = 306 effets, `references/reglages.tsv` = réglages des effets
  clés). Ex. : Amount de Turbulent Displace = `ADBE Turbulent Displace-0002`. Les noms affichés sont anglais.
- Délai maximal d'une requête du canal : 60 s par le protocole. Un rendu court passe (1 s de 1080×1920 à 60 i/s ≈ 4,5 s) ;
  pour un rendu long, découper en plusieurs requêtes ou rendre par `render-frame` + assemblage, et vérifier.
- `new File(p).exists` renvoie `false` juste après un rendu : vérifier le fichier sur le disque depuis le terminal.
- **Le son** : mixer hors de l'app (ffmpeg) et poser sur la vidéo rendue. ffmpeg de Remotion (`npx remotion ffmpeg`) n'a
  PAS les filtres `fps`, `tile`, `select`… : utiliser le ffmpeg du système (`/opt/homebrew/bin/ffmpeg`) pour les planches.
- Une distorsion posée sur un texte est coupée à ses bords : la poser sur un **calque d'effets plein cadre** (`calqueEffets`).
- Les icônes officielles d'app (PNG 1024) ont 100 px de marge transparente de chaque côté (visible : 824 px).
- **Expressions (testé : vague par lettre OK)** : `ADBE Text Animators` → `addProperty("ADBE Text Animator")` ; sélecteur
  `ADBE Text Selectors` → `addProperty("ADBE Text Expressible Selector")` (puis `property(1).remove()` pour enlever le
  sélecteur de plage) ; propriétés d'animateur : `ADBE Text Position 3D`, `ADBE Text Rotation`, `ADBE Text Scale 3D`,
  `ADBE Text Fill Color`, `ADBE Text Blur`, `ADBE Text Opacity`. Pièges :
  - le réglage `Amount` (`property("Amount")`) a **3 valeurs** : une expression qui renvoie un scalaire est **ignorée sans erreur**
    (valeur par défaut 100 % partout) → toujours renvoyer `[v, v, v]` ;
  - **`thisComp.frameRate` n'existe pas** (NaN silencieux) : utiliser `time / thisComp.frameDuration` (ou `timeToFrames(time)`) ;
  - `textIndex` (1-based) marche au rendu ; `expressionError` reste vide même quand l'expression est fausse : vérifier en rendant ;
  - `p.valueAtTime(t, false)` évalue l'expression hors contexte lettre (textIndex = 1) : utile pour tester `time`, pas la vague complète.
  Script de référence : `mon-atelier/scripts/vague.jsx` (`connaissances/skills-backup/` n'en a pas besoin, il est dans le projet).
- Non encore testé : masques avec `ADBE Extract`, calques de forme multi-éléments, caméra 3D.
- Alternative sans script : CLI `effectcraft-cli` (exec, set, get, run, render-frame, script, render, mcp) et serveur MCP
  `effectcraft-cli mcp --bridge 9877`. Pas installés ; les ajouter seulement si besoin (zip dans les Releases GitHub
  storytold/effectcraft : demander l'accord de l'élève avant de télécharger).

## 4. Recettes (reprises de la formation, à adapter)
**Vague par lettre** (testée dans EffectCraft : OK, voir pièges des expressions ci-dessus ; chaque lettre fait son propre ressort) : un sélecteur d'expression par animateur
(`ADBE Text Expressible Selector`, propriété `ADBE Text Expressible Amount`). La lettre i naît à l'image 12 + 2i
(60 i/s) ; t = images depuis sa naissance ; d(t) = e^(−0,145 t) · (cos 0,205 t − 0,26 sin 0,205 t) (1 → 0,61 → 0,28 →
0,04 → −0,17 vers 11 images → 0 vers 22). Animateur « vague » (+216 px vers le bas, 32°, échelle 60 %) sur max(d, 0) ;
animateur « dépassement » (−216 px, −32°, 140 %) sur max(−d, 0) ; animateur « pâle » (couleur claire + flou 5) sur
max(d, 0) ; « naissance » (opacité 0) avant la naissance.

**Logo qui remplit l'écran (effet « PayPal »)** : à l'image où l'icône commence à grossir, la remplacer par un carré
arrondi (solide 1000 × 1000, masque rayon 224, effet Ramp `ADBE Ramp` aux couleurs mesurées de l'icône) + le logo seul
(même PNG, masque autour du logo, effet `ADBE Extract` qui garde la partie claire). Le carré grandit en accélérant
(× 1,9 → 2,4 → 3,2 → 4,5 → 7 → 12 en 2 images chacune) ; le logo garde presque sa taille (× 1,15), puis devient le logo
du plein écran (× 1,72) ; le nom de l'app apparaît dessous (fondu + montée de 22 px, flou 10 → 0).

**Distorsions** : négatif (`ADBE Invert`, 2 images), fonte liquide (`ADBE Turbulent Displace`, Amount 80-250, testé OK),
coup de zoom (`ADBE Optics Compensation`), pixels (`ADBE Mosaic`), coup de fouet (`ADBE Motion Blur`), lueur (`ADBE Glo2`).

## 5. Vérifier avant de montrer
Rendre, puis regarder les images : `ffmpeg -i rendu.mp4 -vf "fps=5,scale=320:-1,tile=5x1" -frames:v 1 planche.png`
(ffmpeg du système) et comparer à ce qui est attendu, image par image (skill `analyse-image`). Ne jamais dire « c'est fait »
sans avoir regardé.

## 6. Acquis supplémentaires (clone « Chante avec tes artistes », 2026-10-11)
- **Formats** : ne pas présumer du vertical : lire la référence (`ffprobe`). Exemple de la formation = 1920×1080 60 i/s.
- **Importer / poser une image** : `img = app.project.importFile(new ImportOptions(new File(chemin))); l = c.layers.add(img); tr(l,"ADBE Anchor Point").setValue([w/2,h/2])` ; échelle en % = taille_voulue / largeur_png × 100.
- **Mesurer un texte** : `l.sourceRectAtTime(0,false).width` (texte justifié au centre : l'origine est le milieu de la ligne de base). Caler une police : créer à 100 px, mesurer, `taille = 100 × largeur_cible / largeur_100`.
- **Polices** : `Inter-Regular|Medium|SemiBold|Bold|Italic` (embarquées). `app` expose `text.fonts` (`ec.py --methode execute '{"command":"text.fonts","params":{"query":"Inter"}}'`).
- **Effets testés (matchName ADBE)** : `ADBE Gaussian Blur 2` (`-0001` = flou, animable), `ADBE Motion Blur` (`-0001` angle, `-0002` distance : flou directionnel pour des traînées), `ADBE Drop Shadow` (`-0001` couleur, `-0002` opacité %, `-0003` direction, `-0004` distance, `-0005` adoucissement).
- **Calque de forme** : rectangle arrondi = groupe `ADBE Vector Group` → `ADBE Vector Shape - Rect` (`ADBE Vector Rect Size`, `ADBE Vector Rect Roundness`) + `ADBE Vector Graphic - Fill` ; reprendre les éléments par matchName après tout ajout. Un dégradé (`ADBE Vector Graphic - G-Fill`, propriétés start/end/colors) existe mais `Colors` est un objet non réglé par script : préférer un **PNG dégradé** fabriqué avec Pillow.
- **Flou de mouvement** : `comp.motionBlur = true` + `layer.motionBlur = true` marchent.
- **Clés** : une clé par image avec une fonction `valeur(f)` = le plus fidèle pour copier des mesures (60 clés par propriété : sans problème). `setValueAtTime` linéaire par défaut.
- **Texte grisé par lettres** : un animateur à sélecteur d'expression `(textIndex > n) ? 100 : 0` avec `ADBE Text Fill Color`.
- **Parenting** : `layer.parent = autre` fonctionne (API), mais la caméra par fonction s(f) (position/échelle clés) est plus sûre.
- **Voir aussi** le skill `motion-reference-clone` (méthode complète de copie d'une référence) et le skill `analyse-image`.
- **Port du canal** : si une autre instance d'EffectCraft tourne déjà (lancée sans `--control`), `ec.py --port <n>` vise celle qui écoute ; sinon quitter l'app (Cmd+Q) et laisser `ec.py` la relancer sur 9877.
