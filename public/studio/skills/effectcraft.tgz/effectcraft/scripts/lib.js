// Boîte à outils (ajoutée APRÈS ton script par ec.py ; fonctions remontées, pas d'état global).
// Interface d'EffectCraft en ANGLAIS. Les matchName « ADBE … » d'After Effects fonctionnent (306 effets : references/effets.tsv).
function j(m) { $.writeln(String(m)); }
// Ajoute un effet par matchName (ex. "ADBE Turbulent Displace") et le renvoie.
function effet(calque, matchName) { return calque.property("ADBE Effect Parade").addProperty(matchName); }
// Réglage d'un effet par matchName (ex. "ADBE Turbulent Displace-0002" = Amount). Voir references/reglages.tsv.
function reglage(fx, matchName) { return fx.property(matchName); }
// Images clés en IMAGES : cles(prop, comp, [[image, valeur], ...]).
function cles(prop, comp, liste) {
  for (var i = 0; i < liste.length; i++) prop.setValueAtTime(liste[i][0] * comp.frameDuration, liste[i][1]);
}
// Calque d'effets plein cadre (les distorsions d'un texte ou d'une forme sont coupées à ses bords).
function calqueEffets(comp, nom) {
  var s = comp.layers.addSolid([1, 1, 1], nom || "Effets", comp.width, comp.height, comp.pixelAspect, comp.duration);
  s.adjustmentLayer = true;
  return s;
}
// Rendu par la file d'attente. chemin AVEC extension (.mp4, .mov, .gif… : EffectCraft n'en ajoute pas). modele (ANGLAIS) : "H.264 - Match Render Settings - 15 Mbps", "H.264", "ProRes",
// "PNG Sequence", "GIF"… Bloque jusqu'à la fin ; renvoie le chemin.
function rendre(comp, chemin, modele) {
  var rq = app.project.renderQueue.items.add(comp);
  var om = rq.outputModule(1);
  if (modele) { try { om.applyTemplate(modele); } catch (e) { if (String(e).indexOf("nothing to change") < 0) throw e; } }   // « nothing to change » = déjà ce modèle
  om.file = new File(chemin);
  app.project.renderQueue.render();
  var sortie = om.file.fsName;
  rq.remove();
  return sortie;
}
