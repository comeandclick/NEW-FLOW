#!/usr/bin/env python3
"""Exécute un script JavaScript (style After Effects) dans EffectCraft via son canal de contrôle (TCP 127.0.0.1).
Usage : python3 ~/.claude/skills/effectcraft/scripts/ec.py /chemin/absolu/script.jsx [--port 9877]
        python3 ec.py --methode commands '{"filter":"layer"}'     (appel brut engine.*)
- ouvre EffectCraft avec le canal de contrôle s'il n'est pas joignable ;
- ajoute lib.js APRÈS le script (les fonctions sont remontées : pas de #include) ;
- affiche le journal ($.writeln), la valeur de la dernière expression et l'erreur éventuelle (avec la ligne).
Code de sortie : 0 = ok, 1 = erreur du script, 2 = EffectCraft injoignable."""
import json, os, socket, subprocess, sys, time, glob

PORT = 9877
if "--port" in sys.argv:
    i = sys.argv.index("--port"); PORT = int(sys.argv[i + 1]); del sys.argv[i:i + 2]
ICI = os.path.dirname(os.path.abspath(__file__))

def appel(methode, params, timeout=600):
    s = socket.create_connection(("127.0.0.1", PORT), timeout=timeout)
    s.sendall((json.dumps({"id": 1, "method": methode, "params": params}) + "\n").encode())
    buf = b""
    while b"\n" not in buf:
        d = s.recv(65536)
        if not d: break
        buf += d
    s.close()
    return json.loads(buf.decode())

def joignable():
    try:
        socket.create_connection(("127.0.0.1", PORT), timeout=2).close(); return True
    except OSError:
        return False

def lancer():
    cands = ["/Applications/EffectCraft.app", os.path.expanduser("~/Applications/EffectCraft.app")] + sorted(glob.glob("/Volumes/EffectCraft*/EffectCraft.app"))
    app = next((c for c in cands if os.path.isdir(c)), None)
    if not app:
        print("EffectCraft introuvable (/Applications ni disque monté). Installe-le : ouvre le .dmg et glisse l'app dans Applications.")
        sys.exit(2)
    print("EffectCraft n'est pas joignable : lancement…", file=sys.stderr)
    subprocess.Popen(["open", "-n", "-a", app, "--args", "--control", str(PORT)])
    for _ in range(60):
        time.sleep(1)
        if joignable(): time.sleep(1); return
    print("EffectCraft ne répond pas sur le port %d." % PORT); sys.exit(2)

if not joignable(): lancer()

if "--methode" in sys.argv:
    i = sys.argv.index("--methode")
    m = "engine." + sys.argv[i + 1]
    p = json.loads(sys.argv[i + 2]) if len(sys.argv) > i + 2 else {}
    print(json.dumps(appel(m, p), ensure_ascii=False, indent=1)); sys.exit(0)

chemin = sys.argv[1]
code = open(chemin, encoding="utf-8").read() + "\n;\n" + open(os.path.join(ICI, "lib.js"), encoding="utf-8").read()
r = appel("engine.execute", {"command": "script.run", "params": {"code": code, "name": os.path.basename(chemin)}})
if not r.get("ok"):
    print("ERREUR canal :", r.get("error")); sys.exit(1)
res = r["result"]
if res.get("output"): print(res["output"].rstrip("\n"))
if res.get("ok") and res.get("result") not in (None, "undefined"): print("=>", res["result"])
if not res.get("ok"):
    e = res.get("error") or {}
    print("ERREUR script : %s (ligne %s, colonne %s)" % (e.get("message"), e.get("line"), e.get("column"))); sys.exit(1)
