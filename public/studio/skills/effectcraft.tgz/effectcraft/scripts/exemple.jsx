// Exemple complet (sert de test) : texte + calque d'effets Turbulent Displace animé, rendu en H.264, 60 i/s.
// Lancer : python3 ~/.claude/skills/effectcraft/scripts/ec.py ~/.claude/skills/effectcraft/scripts/exemple.jsx
(function () {
  try {
    app.beginUndoGroup("Exemple Claude");
    var c = app.project.items.addComp("Exemple Claude", 960, 540, 1, 1, 60);
    c.layers.addSolid([0.05, 0.05, 0.08], "Fond", 960, 540, 1, 1);
    var t = c.layers.addText("DISTORSION");
    var td = t.property("ADBE Text Properties").property("ADBE Text Document");
    var d = td.value; d.fontSize = 110; d.fillColor = [1, 0.15, 0.25]; d.justification = ParagraphJustification.CENTER_JUSTIFY; td.setValue(d);
    t.property("ADBE Transform Group").property("ADBE Position").setValue([480, 300]);
    var fx = effet(calqueEffets(c), "ADBE Turbulent Displace");
    cles(reglage(fx, "ADBE Turbulent Displace-0002"), c, [[0, 0], [30, 140], [59, 0]]);
    reglage(fx, "ADBE Turbulent Displace-0003").setValue(90);
    app.endUndoGroup();
    var f = rendre(c, "/tmp/exemple_claude.mp4", "H.264 - Match Render Settings - 15 Mbps");
    j("rendu : " + f);
    c.openInViewer(); c.time = 0.5;
  } catch (e) { j("ERREUR : " + e + " (ligne " + e.line + ")"); }
})();
