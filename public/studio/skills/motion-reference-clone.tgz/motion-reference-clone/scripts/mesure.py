#!/usr/bin/env python3
"""Mesures image par image sur les images extraites par analyse-image/feuilleter.sh (dossier images/i_00001.jpg…).
Sous-commandes (coordonnées en pixels PLEINE résolution) :
  icone  <images> [debut fin]        largeur + centre de l'objet coloré (rouge par défaut ; --rgb min_r,max_g,max_b) à chaque image
  lignes <images> <image>            lignes de texte, mots (groupes séparés par un blanc), couleur du texte
  bas    <images> <image> x0 x1 y0 y1  haut/bas (ligne de base) du texte dans une zone
  blanc  <images> [debut fin pas]    boîtes des éléments clairs sur fond coloré (logo / étiquette finale)
  fond   <images> <image>            couleurs du fond (coins, haut/milieu/bas)
Pourquoi : un échantillonnage visuel rate la poussée de caméra lente (échelle 1 → 1,37 centrée sur l'icône), les trajectoires et les tailles exactes."""
import sys, numpy as np
from PIL import Image
def charge(d, n, scale=1.0):
    im = Image.open("%s/i_%05d.jpg" % (d, n)).convert("RGB")
    if scale != 1.0: im = im.resize((int(im.width * scale), int(im.height * scale)))
    return np.asarray(im).astype(int)
def groupes(occ, gap):
    idx = np.where(occ)[0]
    if len(idx) == 0: return []
    out = []; s = p = idx[0]
    for i in idx[1:]:
        if i - p > gap: out.append((int(s), int(p))); s = i
        p = i
    out.append((int(s), int(p))); return out
def main():
    c, d = sys.argv[1], sys.argv[2]
    if c == "icone":
        a = int(sys.argv[3]) if len(sys.argv) > 3 else 1; b = int(sys.argv[4]) if len(sys.argv) > 4 else 9999
        n = a
        while n <= b:
            try: im = charge(d, n, 0.5)
            except FileNotFoundError: break
            m = (im[..., 0] > 200) & (im[..., 1] < 110) & (im[..., 2] < 150)
            ys, xs = np.where(m)
            if len(xs): print("%d:%dx%d@(%d,%d)" % (n, (xs.max() - xs.min()) * 2, (ys.max() - ys.min()) * 2, (xs.min() + xs.max()), (ys.min() + ys.max())), end=" ")
            n += 1
        print()
    elif c == "lignes":
        im = charge(d, int(sys.argv[3])); L = im.mean(2); red = (im[..., 0] > 190) & (im[..., 1] < 120); ink = (L < 180) & ~red
        for (a, b) in groupes(ink.sum(1) > 0, 12):
            info = []
            for (x0, x1) in groupes(ink[a:b + 1].sum(0) > 0, 38):
                px = im[a:b + 1, x0:x1 + 1][ink[a:b + 1, x0:x1 + 1]]; info.append((x0, x1, tuple(np.percentile(px, 10, axis=0).astype(int))))
            print("ligne y", a, b, info)
    elif c == "bas":
        im = charge(d, int(sys.argv[3])); L = im.mean(2); x0, x1, y0, y1 = map(int, sys.argv[4:8])
        m = L[y0:y1, x0:x1] < 180; ys = np.where(m.any(1))[0]; print("haut", ys.min() + y0, "bas (ligne de base)", ys.max() + y0)
    elif c == "blanc":
        a, b, p = (int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])) if len(sys.argv) > 5 else (86, 156, 3)
        for n in range(a, b + 1, p):
            im = charge(d, n); br = (im[..., 1] > 110) & (im[..., 0] > 235); prof = np.where(br.sum(1) > 0)[0]
            if len(prof) == 0: print(n, None); continue
            segs = []; s = prof[0]
            for g in np.where(np.diff(prof) > 8)[0]: segs.append((s, prof[g])); s = prof[g + 1]
            segs.append((s, prof[-1]))
            print(n, [(int(np.where(br[a1:b1 + 1].sum(0) > 0)[0].min()), int(a1), int(np.where(br[a1:b1 + 1].sum(0) > 0)[0].max()), int(b1)) for a1, b1 in segs])
    elif c == "fond":
        im = charge(d, int(sys.argv[3])); h, w = im.shape[:2]
        print("coin", tuple(im[5, 5]), "haut", tuple(im[5, w // 2]), "milieu", tuple(im[h // 2, 50]), "bas", tuple(im[h - 5, w // 2]))
main()
