#!/usr/bin/env python3
"""Mixe les bruitages doux de l'exercice sur la vidéo rendue (hors de l'app de motion : l'ajout d'un son dans la composition peut faire échouer l'export).
Usage : python3 scripts/mixer_sons.py video_muette.mp4 video_finale.mp4
Partition (60 i/s ; le PIC de chaque son tombe sur l'image de l'événement ; temps = image / 60) : voir public/sons/partition.txt.
Chaîne : passe-bas, gain, décalage = instant de l'événement - instant du pic ; mixage ; loudnorm -18 LUFS puis -2,5 dB."""
import subprocess, sys, os, numpy as np
SONS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "public", "sons")
FFMPEG = "ffmpeg"
PARTITION = [  # (image, fichier, passe-bas Hz, gain dB)
    (30, "souffle_a.wav", 1500, -15), (54, "clic.wav", 2500, -13), (64, "clic.wav", 2200, -14),
    (88, "souffle_b.wav", 1800, -5), (90, "impact.wav", 1200, -9), (100, "ouverture.wav", 3000, -12),
]
def pic(fichier, lp):
    raw = subprocess.run([FFMPEG, "-v", "error", "-i", os.path.join(SONS, fichier), "-af", "lowpass=f=%d" % lp, "-ac", "1", "-ar", "48000", "-f", "f32le", "-"], capture_output=True).stdout
    x = np.abs(np.frombuffer(raw, dtype=np.float32)); return float(np.argmax(x)) / 48000
def main(video, sortie, fps=60):
    entrees, filtres, labels = [], [], []
    for i, (img, f, lp, g) in enumerate(PARTITION):
        t0 = max(0.0, img / fps - pic(f, lp))
        entrees += ["-i", os.path.join(SONS, f)]
        filtres.append("[%d:a]aformat=sample_rates=48000:channel_layouts=stereo,lowpass=f=%d,volume=%ddB,adelay=%d|%d[a%d]" % (i + 1, lp, g, round(t0 * 1000), round(t0 * 1000), i))
        labels.append("[a%d]" % i)
        print("image %3d %-14s pic %.3fs -> départ %.3fs" % (img, f, pic(f, lp), t0))
    fc = ";".join(filtres) + ";" + "".join(labels) + "amix=inputs=%d:normalize=0:duration=longest,loudnorm=I=-18:TP=-2:LRA=7,volume=-2.5dB,apad,atrim=0:%.3f[m]" % (len(PARTITION), float(subprocess.check_output(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", video]).decode().strip()))
    subprocess.check_call([FFMPEG, "-v", "error", "-y", "-i", video] + entrees + ["-filter_complex", fc, "-map", "0:v", "-map", "[m]", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", sortie])
if __name__ == "__main__": main(sys.argv[1], sys.argv[2])
