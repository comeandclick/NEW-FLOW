---
name: motion-reference-clone
description: Refaire à l'identique (même qualité, même gabarit, même timing, même son) une vidéo de motion design de référence pour une autre marque - méthode complète « mesurer image par image puis reconstruire par script puis comparer image par image » avec EffectCraft ; contient le modèle chiffré « Chante avec tes artistes » (Apple Music) et un script réutilisable. À charger dès que l'utilisateur donne une vidéo de référence à recopier, adapter à sa marque ou à améliorer.
---

# Cloner une vidéo de référence (méthode éprouvée)
Fait ses preuves sur « Chante avec tes artistes » refait pour Kalimat (2026-10-11). Utilisateur non développeur : tu fais tout, tu montres les résultats, français simple.

## Méthode (dans l'ordre, ne rien sauter)
1. **Lire les consignes de fond avant de construire** : format/cadence de la référence (`ffprobe` : ici 1920×1080 60 i/s, PAS vertical : ne jamais présumer du format), couleurs, polices, son fourni (+ partition). Les consignes de l'utilisateur priment (ex. fond blanc au lieu de gris-lavande).
2. **Feuilleter TOUTES les images** (skill `analyse-image`, `feuilleter.sh <video> analyse/<nom> 60`) et lire toutes les planches. Rendu exporté = cadence d'origine (60) ; enregistrement d'écran de Reel = 30.
3. **Mesurer, ne pas deviner** (`scripts/mesure.py`) : taille/centre de l'objet coloré à chaque image (`icone`), mots et couleurs (`lignes`), lignes de base (`bas`), éléments clairs sur fond coloré (`blanc`), fond (`fond`). Ce qu'on découvre ainsi et qu'un coup d'œil rate : une **poussée de caméra lente** (échelle ×1 → ×1,37 centrée sur l'icône, tout grossit ensemble : texte, icône, étiquette), des trajectoires précises, la taille exacte des polices.
4. **Écrire la table des événements** (images de début/fin, courbes) dans `references/` du projet, avec les tableaux de valeurs.
5. **Construire par script** (skill `effectcraft`). Modèle prêt : `modeles/chante-avec-tes-artistes.jsx` (bloc CONFIG en tête : textes, logo, plaque, fond, sorties). Principes qui donnent la qualité :
   - **échelle de police calée sur la largeur mesurée** : créer un texte à 100 px, lire `sourceRectAtTime().width`, déduire la taille (ici 176/129 px ≈ recette 180/130 → Inter SemiBold confirmé) ;
   - **caméra = fonction s(f)** : position écran = C + s·(p − C), échelle = s ; clés image par image (pas de parent) ;
   - tables mesurées copiées telles quelles (largeur du carré, centre, hauteur du logo) plutôt que des courbes d'accélération « à l'œil » ;
   - plaque d'icône = **PNG dégradé pré-fabriqué** (Pillow) plutôt qu'une forme : dégradé + bords nets, flou et ombre faciles ;
   - logo = PNG à fond transparent fabriqué par script Python (alpha = distance au fond), plus fiable que l'effet Extract ;
   - texte plus large que la référence ? réduire la police pour qu'il reste à l'écran jusqu'à la fin de la poussée (largeur max paramétrable).
6. **Comparer image par image** : `analyse-image/scripts/comparer.sh ref.mp4 copie.mp4 analyse/cmp 60`, lire TOUTES les planches (réf. à gauche, copie à droite), corriger les écarts (taille, moment, vitesse, contraste), recommencer.
7. **Son** : `scripts/mixer_sons.py muette.mp4 finale.mp4` (passe-bas, gain, décalage = instant − pic, loudnorm, −2,5 dB). **Vérifier** les pics de la copie contre ceux de la référence (RMS 10 ms) et la sonie (`ffmpeg -af ebur128`).
8. **Noter l'apprentissage** (obligatoire) : mettre à jour ce skill, `effectcraft`, et `connaissances/` du projet (valeurs mesurées, pièges, décisions de l'utilisateur).

## Pièges vus
- Ne pas confondre fond de la référence et fond demandé : la référence a un fond gris-lavande (229,228,234) ; l'utilisateur a demandé blanc. Une plaque crème sur blanc est illisible : ajouter une **ombre douce** (Drop Shadow opacité 24, direction 180, distance 7, adoucissement 18, qui disparaît pendant la croissance).
- Une icône à logo fin (calligraphie) paraît petite : agrandir le logo (×1,15 par rapport aux mesures du glyphe plein) pour garder la présence.
- Mot de remplacement plus long que l'original = naissance des lettres 12 + 2i continue plus longtemps (16 lettres → dernière née image 42) : OK tant que la poussée (image 34+) démarre après ; sinon décaler.
- Numérotation : images de la référence depuis 1 (image 1 = temps 0) ; la recette est en images depuis 0 (temps = image/60). Dans le script : `T(f) = (f−1)/60` et expressions avec `time / thisComp.frameDuration` (0-based).
- Expression de sélecteur de texte : `Amount` = 3 valeurs → renvoyer `[v,v,v]` ; `thisComp.frameRate` n'existe pas (voir skill `effectcraft`).
- Rendu dans EffectCraft = muet ; le son se pose ensuite (ffmpeg).
- ffmpeg de Remotion sans filtres : utiliser `/opt/homebrew/bin/ffmpeg` pour planches et mixage.

## Fichiers
- `references/modele-apple-music.md` : toutes les mesures du modèle (caméra, positions, tableaux, couleurs, sons).
- `modeles/chante-avec-tes-artistes.jsx` : script de reconstruction paramétrable.
- `scripts/mesure.py`, `scripts/mixer_sons.py`.

## Export 4K (testé 2026-10-11)
- Vrai 4K = refaire le script avec un facteur `K = 2` (comp 3840×2160, polices × K, positions × K, flous/ombres × K, échelles des PNG × K). **Ne pas** imbriquer la comp 1080p dans une comp 4K (même avec `collapseTransformations`, c'est un agrandissement flou).
- **Piège** : une variable `K` redéclarée plus loin dans le script (ici le facteur 1,32 des mots fantômes) écrase le facteur de définition (`var` est remonté) : tout est à 66 %. Donner des noms uniques (`KF`).
- Débit : le module de sortie JS n'a pas de débit. Laisser en file d'attente (`RENDRE = false`), puis `ec.py --methode execute '{"command":"renderQueue.setOutputModule","params":{"index":1,"bitrate":60000,"rateControl":"bitrate"}}'`, puis `app.project.renderQueue.render()`. Vider d'abord la file (`while(renderQueue.numItems>0) renderQueue.item(1).remove()`), sinon `index:1` vise un vieux rendu. Le mode `quality` donne un débit plus bas (13 Mbit/s) que `bitrate` 60000 (≈ 26 Mbit/s sur ce contenu simple).
- Le rendu 4K de 156 images dépasse parfois le délai du canal (« ERREUR canal : timeout ») mais finit : attendre le fichier, vérifier `ffprobe -count_frames`, puis mixer.
