// Kalimat — copie du modèle « Exemple Apple Music - Chante avec tes artistes » (1920x1080, 60 i/s, 156 images), fond BLANC.
// Mesures prises image par image sur la référence (analyse/apple-music, voir connaissances/modele-apple-music.md).
// Lancer : python3 ~/.claude/skills/effectcraft/scripts/ec.py /Users/aymen/Developer/mon-atelier/scripts/kalimat_v2.jsx
(function () {
  try {
    app.beginUndoGroup("Modele Apple Music");
    // ===== CONFIG (seule partie à changer pour une autre marque / d'autres textes) =====
    var NOM = "Kalimat - modele Apple Music 4K";                 // nom de la composition
    var TXT1 = "Apprends l'arabe", GRIS_APRES = 9;           // ligne 1 ; les lettres au-delà de GRIS_APRES (espace compris) sont grises
    var TXT2A = "à ton", TXT2B = "rythme";                   // ligne 2 : mot gauche [icône] mot droit
    var ETIQ = "Kalimat", NOMF_TXT = "Kalimat";              // étiquette à côté de l'icône au début ; nom final sous le logo
    var BG = [1, 1, 1];                                      // fond (blanc ; la référence est gris-lavande 229,228,234)
    var LOGO = "/Users/aymen/Developer/mon-atelier/public/kalimat/logo.png";       // logo seul, fond transparent, 1024x1024
    var PLAQUE = "/Users/aymen/Developer/mon-atelier/public/kalimat/plaque.png";   // carré arrondi dégradé 1024x1024 (rayon 22,4 %)
    var BB = {cx: 0.4927, cy: 0.4541, w: 0.5361, h: 0.6074};  // boîte du logo dans son carré 1024 (mesurée sur l'alpha)
    var K = 2;                                               // facteur de définition : 1 = 1920x1080, 2 = 3840x2160 (4K, tout est redessiné net, pas agrandi)
    var RENDRE = false;                                      // false = laisser en file d'attente (pour régler le débit : ec.py --methode execute renderQueue.setOutputModule {"index":1,"bitrate":60000}) ; true = rendre tout de suite (débit par défaut ≈ 13 Mbit/s)
    var LIGNE1_MAX = 1250;                                   // largeur max de la ligne 1 (px) pour qu'elle reste à l'écran
    var SORTIE = "/Users/aymen/Developer/mon-atelier/out/kalimat_4k_muet.mp4";
    var PROJET = "/Users/aymen/Developer/mon-atelier/kalimat.ecproj";
    // ====================================================================================
    for (var q = app.project.numItems; q >= 1; q--) if (app.project.item(q).name === NOM) app.project.item(q).remove();
    var W = 1920 * K, H = 1080 * K, FPS = 60, N = 156;
    function P(x, y) { return [x * K, y * K]; }               // point en coordonnées 1920x1080 -> comp
    var c = app.project.items.addComp(NOM, W, H, 1, N / FPS, FPS);
    c.motionBlur = true;
    var ENCRE = [42 / 255, 41 / 255, 45 / 255], GRIS = [101 / 255, 100 / 255, 106 / 255];
    var CX = 821.5, CY = 700;                               // centre de la « caméra » = centre de l'icône au repos
    function T(f) { return (f - 1) * c.frameDuration; }      // image 1 = temps 0 (numérotation de la référence)
    function tr(l, n) { return l.property("ADBE Transform Group").property(n); }
    function lerp(tab, f) {                                   // tab = [[f, v], ...] ; v nombre ; interpolation linéaire, bornée
      if (f <= tab[0][0]) return tab[0][1];
      for (var i = 1; i < tab.length; i++) if (f <= tab[i][0]) { var a = tab[i - 1], b = tab[i], u = (f - a[0]) / (b[0] - a[0]); return a[1] + (b[1] - a[1]) * u; }
      return tab[tab.length - 1][1];
    }
    // ---------- mesures de la référence ----------
    // largeur de l'icône (px) images 1..69 : l'icône + « Musique » grossissent puis reviennent au repos, puis poussée douce
    var WIC = [182, 184, 186, 186, 188, 190, 190, 192, 194, 194, 196, 196, 196, 192, 186, 180, 174, 172, 168, 164, 162, 158, 156, 156, 154, 154, 154, 154, 154, 154, 154, 154, 154, 156, 156, 156, 158, 158, 160, 160, 162, 162, 164, 164, 166, 168, 168, 170, 170, 172, 174, 174, 176, 180, 182, 184, 186, 188, 190, 192, 194, 196, 198, 200, 202, 204, 206, 208, 210];
    // carré qui grandit, images 70..90 : largeur et centre
    var SQW = [216, 222, 228, 238, 248, 260, 274, 288, 310, 332, 368, 410, 462, 522, 602, 698, 826, 986, 1222, 1522, 2200];
    var SQX = [822, 821, 822, 823, 826, 828, 831, 836, 841, 846, 852, 859, 865, 873, 881, 891, 901, 913, 928, 945, 960];
    var SQY = [700, 699, 699, 698, 698, 696, 694, 693, 690, 688, 684, 678, 673, 667, 657, 646, 628, 602, 572, 550, 540];
    var CAMTAIL = [1.346, 1.349, 1.352, 1.355, 1.357, 1.358, 1.36, 1.362, 1.363, 1.364, 1.365];  // échelle du texte images 69..79
    function cam(f) {
      if (f <= 69) return WIC[f - 1] / 156;
      if (f <= 79) return CAMTAIL[f - 69];
      return 1.37;
    }
    function sq(f) { return f < 70 ? {w: WIC[f - 1], x: CX, y: CY} : (f > 90 ? {w: 2600, x: 960, y: 540} : {w: SQW[f - 70], x: SQX[f - 70], y: SQY[f - 70]}); }
    function wx(x, s) { return CX + s * (x - CX); }
    function wy(y, s) { return CY + s * (y - CY); }
    function clesK(prop, liste) { for (var i = 0; i < liste.length; i++) prop.setValueAtTime(T(liste[i][0]), liste[i][1] * K); }
    function clesT(prop, liste) { for (var i = 0; i < liste.length; i++) prop.setValueAtTime(T(liste[i][0]), liste[i][1]); }
    // clés image par image : fn(f) renvoie la valeur
    function cleF(prop, f0, f1, fn) { for (var f = f0; f <= f1; f++) prop.setValueAtTime(T(f), fn(f)); }

    // ---------- fond blanc ----------
    c.layers.addSolid(BG, "Fond blanc", W, H, 1, N / FPS);

    // ---------- tailles de police calées sur les largeurs mesurées ----------
    function larg(str, fonte) {
      var p = c.layers.addText(str); var td = p.property("ADBE Text Properties").property("ADBE Text Document");
      var d = td.value; d.font = fonte; d.fontSize = 100; td.setValue(d);
      var w = p.sourceRectAtTime(0, false).width; p.remove(); return w;
    }
    var S1 = 100 * (602 / larg("Chante", "Inter-SemiBold") + 388 / larg("avec", "Inter-SemiBold")) / 2;     // ligne 1
    var wL1 = larg(TXT1, "Inter-SemiBold") * S1 / 100; if (wL1 > LIGNE1_MAX) S1 = S1 * LIGNE1_MAX / wL1;      // la ligne tient dans l'écran même poussée à ×1,37
    var S2 = 100 * (185 / larg("tes", "Inter-SemiBold") + 460 / larg("artistes", "Inter-SemiBold")) / 2;    // ligne 2
    var SL = 100 * 273 / larg("Musique", "Inter-Medium");                                                     // étiquette
    j("tailles : ligne1 " + S1.toFixed(1) + "  ligne2 " + S2.toFixed(1) + "  etiquette " + SL.toFixed(1));
    function texte(str, fonte, taille, couleur, nom) {
      var l = c.layers.addText(str); l.name = nom;
      var td = l.property("ADBE Text Properties").property("ADBE Text Document");
      var d = td.value; d.font = fonte; d.fontSize = taille * K; d.fillColor = couleur; d.justification = ParagraphJustification.CENTER_JUSTIFY; td.setValue(d);
      return l;
    }

    // ---------- étiquette « Kalimat » à côté de l'icône (images 1..24) ----------
    var LAB = texte(ETIQ, "Inter-Medium", SL, ENCRE, "Etiquette");
    var wLab = LAB.sourceRectAtTime(0, false).width / K;
    var labX = 899.5 + 42 + wLab / 2, labY = 723;
    cleF(tr(LAB, "ADBE Scale"), 1, 25, function (f) { var s = cam(f) * 100; return [s, s]; });
    cleF(tr(LAB, "ADBE Position"), 1, 25, function (f) { var s = cam(f); return P(wx(labX, s), wy(labY, s)); });
    clesT(tr(LAB, "ADBE Opacity"), [[1, 100], [16, 100], [18, 75], [20, 42], [22, 18], [24, 0]]);
    clesK(reglage(effet(LAB, "ADBE Gaussian Blur 2"), "ADBE Gaussian Blur 2-0001"), [[1, 0], [16, 0], [20, 5], [24, 10]]);

    // ---------- ligne 1 : « Apprends l'arabe », vague par lettre (lettre i née à l'image 12 + 2 i) ----------
    var L1 = texte(TXT1, "Inter-SemiBold", S1, ENCRE, "Ligne 1");
    var DEF = "var f = time / thisComp.frameDuration; var t = f - (12 + 2 * (textIndex - 1));" +
              "var d = (t < 0) ? 0 : Math.exp(-0.145 * t) * (Math.cos(0.205 * t) - 0.26 * Math.sin(0.205 * t));";
    function animateur(nom, expr, props) {
      var an = L1.property("ADBE Text Properties").property("ADBE Text Animators").addProperty("ADBE Text Animator");
      an.name = nom;
      var sel = an.property("ADBE Text Selectors");
      sel.addProperty("ADBE Text Expressible Selector"); sel.property(1).remove();
      sel.property(1).property("Amount").expression = DEF + "var v = " + expr + "; [v, v, v];";   // Amount = 3 valeurs
      var pp = an.property("ADBE Text Animator Properties");
      for (var k = 0; k < props.length; k++) pp.addProperty(props[k][0]).setValue(props[k][1]);
    }
    animateur("gris", "(textIndex > " + GRIS_APRES + ") ? 100 : 0", [["ADBE Text Fill Color", GRIS]]);
    animateur("vague", "Math.max(d, 0) * 100", [["ADBE Text Position 3D", [0, 216 * K]], ["ADBE Text Rotation", 32], ["ADBE Text Scale 3D", [60, 60]]]);
    animateur("depassement", "Math.max(-d, 0) * 100", [["ADBE Text Position 3D", [0, -216 * K]], ["ADBE Text Rotation", -32], ["ADBE Text Scale 3D", [140, 140]]]);
    animateur("pale", "Math.max(d, 0) * 100", [["ADBE Text Fill Color", [0.60, 0.60, 0.62]], ["ADBE Text Blur", [5 * K, 5 * K]]]);
    animateur("naissance", "(f < 12 + 2 * (textIndex - 1) - 1) ? 100 : ((f < 12 + 2 * (textIndex - 1) + 1) ? 50 : 0)", [["ADBE Text Opacity", 0]]);
    cleF(tr(L1, "ADBE Scale"), 1, 90, function (f) { var s = cam(f) * 100; return [s, s]; });
    cleF(tr(L1, "ADBE Position"), 1, 90, function (f) { var s = cam(f); return P(wx(961.5, s), wy(520, s)); });
    clesT(tr(L1, "ADBE Opacity"), [[1, 100], [79, 100], [81, 88], [83, 65], [85, 48], [87, 22], [89, 0]]);
    clesK(reglage(effet(L1, "ADBE Gaussian Blur 2"), "ADBE Gaussian Blur 2-0001"), [[1, 0], [79, 0], [81, 3], [83, 6], [85, 9], [88, 12]]);

    // ---------- ligne 2 : « à ton » [icône] « rythme » (mots fantômes qui tombent) ----------
    var A = texte(TXT2A, "Inter-SemiBold", S2, GRIS, "Mot gauche"), B = texte(TXT2B, "Inter-SemiBold", S2, ENCRE, "Mot droit");
    var wA = A.sourceRectAtTime(0, false).width / K, wB = B.sourceRectAtTime(0, false).width / K;
    var Y2 = 765, RIGHT_A = 711, LEFT_B = 933;                // bord droit du mot de gauche, bord gauche du mot de droite (échelle 1)
    var KF = 1.32;                                           // facteur de la recette des mots fantômes
    var OFF_A = [[40, -39], [44, -40], [46, -31], [48, -22], [50, -12], [52, -3], [54, 3], [56, 8], [58, 9], [62, 8], [66, 3], [70, 0]];
    var OP_A = [[40, 28], [46, 69], [54, 97], [58, 100]], SC_A = [[40, 70], [48, 100]], BL_A = [[40, 6], [50, 0]];
    var OFF_B = [[48, -42], [52, -42], [56, -28], [60, -10], [64, 1], [68, 4], [74, 0]];
    var OP_B = [[48, 28], [54, 69], [62, 97], [66, 100]], SC_B = [[48, 70], [56, 100]], BL_B = [[48, 18], [58, 0]];
    function fantome(l, isLeft, off, op, sc, bl, f0) {
      cleF(tr(l, "ADBE Position"), f0 - 1, 90, function (f) {
        var s = cam(f), cxs, o = lerp(off, f) * KF;
        var wmot = (isLeft ? wA : wB) * lerp(sc, f) / 100;   // largeur courante (échelle d'entrée)
        var edge;
        var e = sq(f);
        if (isLeft) { var natR = wx(RIGHT_A, s); edge = Math.min(natR, e.x - e.w / 2 + 4); cxs = edge - (wmot * s) / 2; }
        else { var natL = wx(LEFT_B, s); edge = Math.max(natL, e.x + e.w / 2 - 4); cxs = edge + (wmot * s) / 2; }
        return P(cxs, wy(Y2 + o, s));
      });
      cleF(tr(l, "ADBE Scale"), f0 - 1, 90, function (f) { var s = cam(f) * lerp(sc, f); return [s, s]; });
      var ok = [[f0 - 1, 0]]; for (var i = 0; i < op.length; i++) ok.push(op[i]);
      ok.push([84, 100], [88, 0]);                            // s'efface pendant que le carré le pousse
      clesT(tr(l, "ADBE Opacity"), ok);
      var bk = []; for (i = 0; i < bl.length; i++) bk.push(bl[i]);
      clesK(reglage(effet(l, "ADBE Gaussian Blur 2"), "ADBE Gaussian Blur 2-0001"), bk);
      var mb = effet(l, "ADBE Motion Blur");                   // traînée horizontale quand le carré pousse les mots
      clesT(reglage(mb, "ADBE Motion Blur-0001"), [[f0, 0], [90, 0]]);
      clesK(reglage(mb, "ADBE Motion Blur-0002"), [[f0, 0], [74, 0], [80, 18], [84, 70], [88, 150]]);
    }
    fantome(A, true, OFF_A, OP_A, SC_A, BL_A, 40);
    fantome(B, false, OFF_B, OP_B, SC_B, BL_B, 48);

    // ---------- carré crème qui grandit + logo ----------
    var PQ = app.project.importFile(new ImportOptions(new File(PLAQUE)));
    var SQL = c.layers.add(PQ); SQL.name = "Carre";
    tr(SQL, "ADBE Anchor Point").setValue([512, 512]);
    SQL.motionBlur = true;
    cleF(tr(SQL, "ADBE Scale"), 1, 91, function (f) { var s = sq(f).w * K / 1024 * 100; return [s, s]; });
    cleF(tr(SQL, "ADBE Position"), 1, 91, function (f) { var e = sq(f); return P(e.x, e.y); });
    var OMB = effet(SQL, "ADBE Drop Shadow");                 // ombre douce : la plaque crème reste lisible sur le blanc
    reglage(OMB, "ADBE Drop Shadow-0003").setValue(180); reglage(OMB, "ADBE Drop Shadow-0004").setValue(7 * K); reglage(OMB, "ADBE Drop Shadow-0005").setValue(18 * K);
    clesT(reglage(OMB, "ADBE Drop Shadow-0002"), [[1, 24], [74, 24], [86, 0]]);
    clesK(reglage(effet(SQL, "ADBE Gaussian Blur 2"), "ADBE Gaussian Blur 2-0001"), [[1, 0], [76, 0], [80, 2], [84, 6], [88, 12]]);
    var HG = [[69, 0], [78, 0], [86, 0], [89, 0], [92, 236], [95, 258], [98, 278], [101, 293], [110, 301], [125, 312], [155, 329]];
    HG[0][1] = 0.607 * 210 * 1.0; HG[1][1] = HG[0][1] * 1.05; HG[2][1] = HG[0][1] * 1.30; HG[3][1] = 190;     // hauteur visible du logo (px)
    var img = app.project.importFile(new ImportOptions(new File(LOGO)));
    var LG = c.layers.add(img); LG.name = "Logo";
    tr(LG, "ADBE Anchor Point").setValue([512, 512]);
    LG.motionBlur = true;
    function logoEtat(f) {
      if (f <= 69) { var e = sq(f), can = e.w * 1.0; return {can: can, x: e.x, y: e.y}; }
      var hg = lerp(HG, f), can2 = hg / BB.h;
      var cx, cy;
      if (f <= 91) { var e2 = sq(f); cx = e2.x; cy = e2.y; }
      else { cx = 942 + (f - 92) * 10 / 63; cy = (f < 92 ? 527 : 624 - hg / 2); }
      // la boîte du logo doit être centrée en (cx, cy) : décaler le centre du carré 1024
      return {can: can2, x: cx - (BB.cx - 0.5) * can2, y: cy - (BB.cy - 0.5) * can2};
    }
    cleF(tr(LG, "ADBE Scale"), 1, 156, function (f) { var s = logoEtat(f).can * K / 1024 * 100; return [s, s]; });
    cleF(tr(LG, "ADBE Position"), 1, 156, function (f) { var e = logoEtat(f); return P(e.x, e.y); });

    // ---------- nom final « Kalimat » sous le logo ----------
    var NOMF = texte(NOMF_TXT, "Inter-SemiBold", 84, ENCRE, "Nom");
    cleF(tr(NOMF, "ADBE Scale"), 98, 156, function (f) { var s = 100 * (f < 110 ? 1 : 1 + 0.037 * (f - 110) / 45); return [s, s]; });
    cleF(tr(NOMF, "ADBE Position"), 98, 156, function (f) { var rise = f >= 106 ? 0 : 18 * (1 - (f - 98) / 8); return P(962, 735 + rise); });
    clesT(tr(NOMF, "ADBE Opacity"), [[97, 0], [98, 0], [106, 100]]);
    clesK(reglage(effet(NOMF, "ADBE Gaussian Blur 2"), "ADBE Gaussian Blur 2-0001"), [[98, 10], [106, 0]]);

    app.endUndoGroup();
    app.project.save(new File(PROJET));
    var rqi = app.project.renderQueue.items.add(c), omm = rqi.outputModule(1);
    try { omm.applyTemplate("H.264"); } catch (e1) { }
    omm.file = new File(SORTIE);
    if (RENDRE) { app.project.renderQueue.render(); rqi.remove(); j("rendu : " + SORTIE); }
    else j("en file d'attente (débit à régler par renderQueue.setOutputModule, puis renderQueue.render) : " + SORTIE);
    c.openInViewer(); c.time = T(60);
  } catch (e) { j("ERREUR : " + e + " (ligne " + e.line + ")"); }
})();
