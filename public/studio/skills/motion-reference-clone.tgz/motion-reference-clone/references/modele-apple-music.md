# Modèle « Chante avec tes artistes » (Apple Music) — mesures image par image
Référence : `Exemple  Apple Music  Chante avec tes artistes.mp4` (formation motionavecia.com). 1920×1080, 60 i/s, 156 images (2,6 s), son AAC. Images numérotées depuis 1 (image 1 = temps 0). Toutes les valeurs sont MESURÉES (outils : `scripts/mesure.py`), sauf mention « recette » (donnée par la formation).

## Structure (6 actes)
| Images | Ce qui se passe |
|---|---|
| 1-16 | Icône d'app + étiquette (« Musique ») au repos, légère poussée (icône 182 → 196 px) |
| 14-25 | L'icône revient à 154 px, l'étiquette s'efface (opacité 100 % → 0 de l'image 16 à 24, flou 0 → 10) |
| 13-~64 | Ligne 1 « Chante avec » écrite lettre par lettre, chaque lettre = ressort (recette ci-dessous) |
| 41-74 | Ligne 2 « tes [icône] artistes » : mots fantômes qui tombent (la ligne 2 contient l'icône : elle ne bouge pas) |
| 34-79 | Poussée de caméra lente : tout grossit de ×1 à ×1,37 autour du CENTRE DE L'ICÔNE (821,5 ; 700) |
| 70-90 | Le carré de l'icône grandit jusqu'à remplir l'écran, pousse les mots de la ligne 2 (traînées), efface la ligne 1 |
| 90-156 | Écran plein couleur : logo seul (poussée lente ×1,38) + nom de l'app qui apparaît dessous |

## Décors et couleurs (référence Apple Music)
Fond (229,228,234) uni · texte foncé (42,41,45) · texte gris (101,100,106) (« avec », « tes ») · fond final dégradé rouge vertical (239,37,97) haut → (237,19,80) milieu → (235,0,66) bas. Icône = carré arrondi rayon 22,4 % (iOS). Police Inter SemiBold (ligne 1 = 176-180 px ; ligne 2 = 129-130 px ; étiquette Inter Medium ≈ 68 px).

## Caméra (échelle s, centre C = (821,5 ; 700))
Toute la scène (texte, icône, étiquette) est mise à l'échelle s(f) autour de C. Position écran d'un point de la scène à l'échelle 1 (x,y) : (Cx + s·(x−Cx), Cy + s·(y−Cy)).
- Largeur de l'icône W(f) images 1..69 (s = W/156) : 182 184 186 186 188 190 190 192 194 194 196 196 196 192 186 180 174 172 168 164 162 158 156 156 154 154 154 154 154 154 154 154 154 156 156 156 158 158 160 160 162 162 164 164 166 168 168 170 170 172 174 174 176 180 182 184 186 188 190 192 194 196 198 200 202 204 206 208 210.
- Texte : s(69)=1,346 puis 1,349 1,352 1,355 1,357 1,358 1,36 1,362 1,363 1,364 1,365 (images 70..79), ≈ 1,37 ensuite.

## Positions à l'échelle 1
- Ligne 1 : centrée x = 961,5 ; ligne de base y = 520 (mesuré 521-523). « Chante » 602 px de large, « avec » 388 px.
- Ligne 2 : ligne de base y = 765 ; bord droit du mot de gauche x = 711 ; icône 743-899 (156 px, centre 821,5 ; 700) ; bord gauche du mot de droite x = 933. « tes » 185 px, « artistes » 460 px. Écart mot-icône ≈ 32-34 px.
- Étiquette initiale : bord gauche à x = 941,5 (icône + 42), ligne de base y ≈ 723, largeur « Musique » 273 px.

## Ligne 1 : vague par lettre (recette, 60 i/s, f = images depuis 0 = image−1)
Lettre i (0 = 1re, espace compris) naît à f = 12 + 2i ; t = f − naissance ; d(t) = e^(−0,145 t)(cos 0,205 t − 0,26 sin 0,205 t), d = 0 avant la naissance.
4 animateurs à sélecteur d'expression : « vague » Pos [0,216] Rot 32° Éch 60 % × max(d,0) ; « dépassement » [0,−216] −32° 140 % × max(−d,0) ; « pâle » (couleur #999 + flou 5) × max(d,0) ; « naissance » opacité 0 avant naissance−1 puis 2 images. Lettres grises : indices > longueur du 1er mot.
Sortie (mesurée) : opacité 100 → 88 (81) → 65 (83) → 48 (85) → 22 (87) → 0 (89) ; flou 0 (79) → 3 → 6 → 9 → 12 (88).

## Ligne 2 : mots fantômes (recette : valeurs × 1,32 px, offset vertical par rapport à la ligne de base)
Mot gauche (départ 40) : y = −39 (40), −40 (44), −31 (46), −22 (48), −12 (50), −3 (52), +3 (54), +8 (56), +9 (58), +8 (62), +3 (66), 0 (70) ; opacité 28 → 69 (46) → 97 (54) → 100 (58) ; échelle 70 → 100 % (40 → 48) ; flou 6 → 0 (40 → 50).
Mot droit (départ 48, plus flou) : y = −42 (48), −42 (52), −28 (56), −10 (60), +1 (64), +4 (68), 0 (74) ; opacité 28 → 69 (54) → 97 (62) → 100 (66) ; échelle 70 → 100 % (48 → 56) ; flou 18 → 0 (48 → 58).
Poussée (images 70-88) : le bord droit du mot gauche = min(position naturelle, bord gauche du carré + 4) ; le bord gauche du mot droit = max(naturelle, bord droit du carré − 4). Traînée horizontale (flou directionnel) 0 (74) → 18 (80) → 70 (84) → 150 (88) ; opacité 100 (84) → 0 (88). Le carré est AU-DESSUS des mots.

## Carré qui grandit (largeur px, centre) images 70..90
Largeur : 216 222 228 238 248 260 274 288 310 332 368 410 462 522 602 698 826 986 1222 1522 (plein écran dès 90).
Centre X : 822 821 822 823 826 828 831 836 841 846 852 859 865 873 881 891 901 913 928 945 960. Centre Y : 700 699 699 698 698 696 694 693 690 688 684 678 673 667 657 646 628 602 572 550 540.
Flou de mouvement fort sur les bords dès l'image 80 (flou 0 → 2 → 6 → 12 de 76 à 88). Dégradé vertical dans le carré.

## Logo (glyphe) et nom
Hauteur visible du glyphe (px) : 206 (92), 225 (95), 242 (98), 255 (101), 262 (110), 271 (125), 286 (155) → poussée lente ×1,38. Bas du glyphe fixe ≈ 624-630 ; centre x 942 → 952. Avant l'image 92 : ×1 au repos, 1,05 (78), 1,15 (86), 1,45 (92) (recette).
Nom (« Apple Music » : 474 px de large, Inter SemiBold, blanc) : opacité 0 jusqu'à l'image 98, 100 à l'image 106 ; monte de 18 px (753 → 735) ; flou 10 → 0 ; grossit de 3,7 % de 110 à 155. Ligne de base ≈ 735 (centre 962).

## Sons (partition fournie) — pic de chaque son sur l'image (temps = image / 60, 0-based)
30 souffle_a (passe-bas 1,5 kHz, −15 dB) · 54 clic (2,5 kHz, −13) · 64 clic (2,2 kHz, −14) · 88 souffle_b (1,8 kHz, −5) · 90 impact (1,2 kHz, −9) · 100 ouverture (3 kHz, −12). Mixage loudnorm −18 LUFS puis −2,5 dB. La référence mesure −21,4 LUFS ; notre mixage −19,8. Vérifié : pics des clics à 54,0 / 64,0 / 87,6 dans la référence, 54,1 / 64,2 / 87,8 dans la copie.
