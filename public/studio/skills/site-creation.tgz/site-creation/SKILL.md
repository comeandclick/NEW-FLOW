---
name: site-creation
description: Créer un site complet (vitrine, boutique, landing, location, admin) qui ne ressemble pas à un site généré par IA. Données jamais inventées, design distinctif, textes humains, fonctionnalités riches, grande phase de polissage (sécurité, performance, responsive, accessibilité, SEO) AVANT le déploiement, déploiement Vercel sur un NOUVEAU projet, compte rendu final. À charger pour toute mission « créer un site ».
---

# Création de site — méthode

Lire aussi `references/anti-ia.md`, `references/fonctionnalites.md`, `references/polissage.md`, `references/livraison-modele.md`.

## 0. Règles qui ne se négocient pas
1. **Ne jamais inventer** : téléphone, e-mail, adresse, WhatsApp, réseaux, horaires, SIRET, prix, noms, avis clients, chiffres (« +500 clients »), certifications, photos de personnes. Donnée absente = on la masque (ou « Sur devis ») et on la liste dans « À compléter » de la livraison. Prévoir dans l'admin un écran « Infos de l'entreprise » pour les saisir ensuite.
2. **Ne jamais toucher à un projet existant** : avant tout déploiement, lister les projets Vercel existants (`vercel project ls`). Créer un projet NEUF au nom unique (`<slug>-<4 caractères>`). Jamais `--force`, jamais `vercel link` vers un projet qui existe déjà, jamais modifier ses domaines ni ses variables.
3. **Chaque image correspond à son sujet** : ouvrir l'image (lecture du fichier) avant de l'utiliser. Une Golf GTI ne montre pas une Bugatti. Pas de photo trompeuse ; texte alternatif exact. Photos fournies par l'utilisateur d'abord ; sinon sources libres vérifiées (Unsplash/Pexels/Wikimedia) avec licence notée, ou illustration/typographie plutôt qu'une mauvaise photo.
4. **Aucun identifiant de démonstration** (« admin / 1234 », « esloc2024 ») : générer un mot de passe fort aléatoire (20+ caractères), stocké haché, à changer à la première connexion ; l'indiquer dans la livraison.
5. **Autonomie** : ne jamais s'arrêter pour demander. Hypothèse = noter dans `HYPOTHESES.md`.

## 1. Compréhension
Relire le brief et les réponses. Lister ce qui manque (coordonnées, prix, catalogue, photos). Voir règle 1.

## 2. Design (voir references/anti-ia.md)
Un site pro a une identité : 1 couple de polices distinctif, 1 palette de 3 couleurs max + neutres teintés, 1 système d'espacement, des composants cohérents, des photos réelles. Décrire le parti pris dans `DESIGN.md` AVANT de coder.

## 3. Fonctionnalités (voir references/fonctionnalites.md)
Un site vide n'est pas livrable : viser la liste « complète » du type de site, côté visiteur ET côté admin.

## 4. Construction
Next.js (App Router) + TypeScript + Tailwind, composants réutilisables, données dans Supabase (ou fichier typé si pas de base), formulaires validés côté serveur (zod), e-mails de notification (Resend ou équivalent gratuit), `.env.example` complet.

## 5. POLISSAGE (obligatoire, AVANT le déploiement)
Suivre `references/polissage.md` point par point, avec preuves (captures, rapports) rangées dans `qa/`. Ne déployer qu'après.

## 6. Déploiement
Projet Vercel NEUF (règle 2) → variables d'environnement → production → vérifier 200 sur toutes les pages + parcours complet en production.

## 7. Livraison
`LIVRAISON.json` + `LIVRAISON.md` selon `references/livraison-modele.md` : « J'ai fini le site », lien, fonctionnalités (visiteur / admin), accès admin, choses à savoir, à compléter.

## 8. Apprendre
Noter dans ce skill ce qui a bien/mal marché (valeurs mesurées, pièges), recopier dans `~/Developer/mon-atelier/connaissances/skills-backup/`.
