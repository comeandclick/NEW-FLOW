// Captures multi-tailles de toutes les pages d'un site : node shots.mjs http://localhost:3000 / /tarifs /admin
// Sortie : qa/captures/<largeur>/<page>.png ; signale tout débordement horizontal. Nécessite : npx playwright install chromium
import { chromium } from 'playwright'
import { mkdirSync } from 'node:fs'
const [base, ...pages] = process.argv.slice(2)
const sizes = [[360, 740], [390, 844], [768, 1024], [1024, 768], [1440, 900], [1920, 1080]]
const b = await chromium.launch()
let bad = 0
for (const [w, h] of sizes) {
  const ctx = await b.newContext({ viewport: { width: w, height: h } })
  const p = await ctx.newPage()
  for (const path of pages.length ? pages : ['/']) {
    await p.goto(base + path, { waitUntil: 'networkidle' }).catch(() => {})
    const over = await p.evaluate(() => document.documentElement.scrollWidth - innerWidth)
    if (over > 1) { bad++; console.log(`DÉBORDEMENT ${over}px : ${path} à ${w}px`) }
    mkdirSync(`qa/captures/${w}`, { recursive: true })
    await p.screenshot({ path: `qa/captures/${w}/${path.replace(/\W+/g, '_') || 'home'}.png`, fullPage: true })
  }
  await ctx.close()
}
await b.close(); console.log(bad ? `${bad} problème(s)` : 'Aucun débordement'); process.exit(bad ? 1 : 0)
