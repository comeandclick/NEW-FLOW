# Éviter le look et le ton « IA »

## Typographie
- Jamais par défaut : Inter, Roboto, Poppins, Montserrat, Space Grotesk, Playfair+Inter. Choisir un couple distinctif et cohérent avec l'activité, via `next/font` (Google Fonts ou Fontshare) : 
  - Premium / auto / immobilier : Fraunces, Newsreader, Instrument Serif, Bricolage Grotesque, Familjen Grotesk, Schibsted Grotesk.
  - Artisan / food / bien-être : Gambetta, Young Serif, DM Serif Display + Figtree, Manrope.
  - Tech / B2B : Geist, General Sans, Satoshi, Onest, Hanken Grotesk.
- 2 familles maximum, 3 graisses. Titres serrés (letter-spacing -0.02em), corps 16–18 px, interligne 1.5–1.65, mesure 60–75 caractères.

## Couleur
- Une couleur d'accent assumée + neutres teintés (jamais #000/#fff purs, jamais gris Tailwind brut). Éviter le dégradé violet-bleu, les halos flous, le « glassmorphism » gratuit, les ombres colorées partout.
- Contraste AA minimum (4.5:1 texte). Tester clair/sombre seulement si demandé.

## Mise en page
- Pas de héros centré « titre + sous-titre + 2 boutons + dégradé » par défaut. Partir des références (WebTwin) et des vraies photos ; asymétrie, grille éditoriale, grands visuels, sections de rythmes différents.
- Pas de grilles de 3 cartes à icônes Lucide identiques en boucle. Pas d'emoji comme icônes. Pas de « badges » décoratifs inutiles.
- Alignements sur une grille de 8 px, espacement généreux et régulier, hiérarchie claire (une idée forte par écran).
- Photos réelles recadrées avec intention ; ratios cohérents ; coins/arrondis cohérents.
- Animations : sobres (80–400 ms), utiles (apparition, survol, transitions de page), `prefers-reduced-motion` respecté.

## Textes (français)
- Écrire comme un rédacteur du métier : concret, court, spécifique (chiffres RÉELS fournis, lieux, conditions).
- Bannir : « Découvrez », « Explorez », « Plongez », « Élevez », « sur mesure », « solutions innovantes », « expérience unique/inoubliable », « à la pointe », « passion », « notre mission est de », « n'hésitez pas à », « au cœur de », « un monde de », les triplets d'adjectifs, les tirets longs en rafale, les points d'exclamation.
- Titres = information (« Golf GTI — 89 €/jour, caution 1 000 € »), boutons = verbes précis (« Réserver du 12 au 15 mars »).
- Typographie française : espaces insécables avant : ; ! ? » et après «, guillemets « », apostrophes ’.
- Relire chaque page à voix haute ; si une phrase pourrait figurer sur n'importe quel site du secteur, la réécrire avec un fait précis ou la supprimer.

## Détails de finition
Favicon et image de partage (OG) soignés ; page 404 utile ; états vides, chargement, erreur ; focus visibles ; sélection de texte aux couleurs de la marque ; liens téléphone/WhatsApp/mail cliquables ; boutons sticky utiles sur mobile.
