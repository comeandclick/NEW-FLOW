# Modèle de LIVRAISON.md (français simple, pour un non-développeur)

```
# J'ai fini le site « <Nom> »

**Lien :** https://…

## Ce que le site permet
### Pour tes visiteurs
- …(fonctionnalités réelles, une ligne chacune)
### Pour toi (administration)
- …

## Accès administration
- Adresse : https://…/admin
- Identifiant : …
- Mot de passe : … (généré pour toi : change-le à la première connexion)

## À savoir
- Ce qui a été décidé à ta place (hypothèses) et pourquoi.
- Ce qui reste à compléter de ton côté (coordonnées, prix, photos…) et où le faire dans l'admin.
- Comptes utilisés (hébergement, base de données, e-mails) et ce qu'ils coûtent éventuellement.
- Limites connues.

## Vérifications faites
Scores Lighthouse, appareils testés, sécurité (résumé en 5 lignes).

## Pour me demander une modification
Écris-moi dans Flow Studio : je reprends le projet là où il en est.
```
`LIVRAISON.json` : `{"statut":"ok","url":"https://…","admin":{"url":"…","identifiant":"…"},"a_completer":["…"]}`.
