# Fonctionnalités attendues (ne pas livrer moins)

## Tous les sites
Pages d'accueil, à propos / contact, mentions légales, politique de confidentialité, cookies (bannière sobre, refus aussi simple que l'accord), 404, plan du site, SEO complet, formulaire de contact validé (serveur) avec notification e-mail et copie en base, anti-spam (honeypot + limite de débit), liens d'action (tél / WhatsApp / mail) uniquement avec les VRAIES coordonnées fournies, multilingue si demandé.

## Vitrine de services / location (ex. location de véhicules)
- Catalogue : liste filtrable (catégorie, prix, disponibilité, options), page détail par élément (galerie de VRAIES photos, caractéristiques, prix, conditions, caution, FAQ), comparaison simple.
- Réservation / devis : formulaire en plusieurs étapes (dates, lieu, options, coordonnées), calcul du prix en direct, vérification de disponibilité (calendrier côté base), confirmation à l'écran et par e-mail, numéro de demande.
- Pages : tarifs et conditions, comment ça marche, zones desservies (carte), FAQ, avis (SEULEMENT de vrais clients fournis), blog/actualités si utile.
- Confiance : conditions claires, assurance, documents demandés, politique d'annulation — uniquement ce que le client a fourni.

## Boutique
Produits, variantes, stock, panier, paiement Stripe (mode test jusqu'à validation), frais de livraison, codes promo, compte client, suivi de commande, factures PDF, e-mails transactionnels, CGV.

## Landing page
Une promesse, une preuve, une action ; formulaire court ; mesure des conversions ; vitesse maximale.

## Admin (indispensable pour vitrine / boutique / location)
- Authentification réelle (Supabase Auth ou équivalent), sessions sécurisées, déconnexion, changement de mot de passe, protection côté SERVEUR de chaque route et action, rôles (admin / éditeur).
- Tableau de bord : indicateurs utiles (demandes du jour, taux de transformation, revenus estimés, prochaines réservations).
- Gestion du catalogue : créer / modifier / supprimer / réordonner, prix, disponibilité, photos (envoi + recadrage + vérification de type et poids), SEO par page.
- Gestion des demandes / réservations / commandes : liste filtrable, statuts (nouveau, confirmé, refusé, terminé), notes internes, e-mail au client en un clic, export CSV, calendrier.
- Contenu : textes de la page d'accueil, FAQ, infos de l'entreprise (coordonnées, horaires, réseaux, mentions légales) modifiables SANS toucher au code.
- Journal d'activité, sauvegarde/export des données, aide courte intégrée.
