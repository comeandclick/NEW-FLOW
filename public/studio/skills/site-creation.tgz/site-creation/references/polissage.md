# Grande phase de polissage (avant déploiement) — preuves dans qa/

## Sécurité
- [ ] En-têtes : CSP stricte, HSTS, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, frame-ancestors ; cookies `HttpOnly; Secure; SameSite`.
- [ ] Entrées : validation serveur (zod) de TOUS les formulaires et API ; échappement ; limites de taille ; limitation de débit (formulaires, connexion) ; anti-spam.
- [ ] Authentification : routes et actions admin vérifiées côté serveur ; pas d'identifiant par défaut ; mots de passe hachés ; verrouillage après échecs.
- [ ] Base : RLS Supabase activée sur chaque table, politiques testées (anonyme ne lit/écrit que ce qui est prévu) ; clé de service jamais côté client.
- [ ] Secrets : aucun dans le code, l'historique Git ni le bundle client (`grep -r` + `git log -p`) ; `.env.example` sans valeur.
- [ ] Envois de fichiers : type, poids, nom nettoyé, stockage privé si besoin.
- [ ] Dépendances : `npm audit --omit=dev` sans critique/haute ; versions épinglées.
- [ ] Pas de `dangerouslySetInnerHTML` non nettoyé, pas d'open-redirect, pas de SSRF.

## Performance (mesurer, ne pas supposer)
- [ ] Lighthouse mobile ≥ 90 (perf, accessibilité, bonnes pratiques, SEO) sur accueil + une page détail + admin.
- [ ] LCP < 2,5 s, CLS < 0,1, INP < 200 ms. Images `next/image` avec tailles réelles, formats modernes, `priority` sur le visuel principal uniquement. Polices `display: swap`, sous-ensemble latin. Pas de bibliothèque lourde inutile (analyser le bundle). Mise en cache et ISR/SSG quand possible.

## Responsive (téléphone ET ordinateur, pas un mobile étiré)
- [ ] Captures Playwright à 360, 390, 768, 1024, 1440, 1920 px de CHAQUE page (script `scripts/shots.mjs`), relues une à une ; aucun débordement horizontal, aucun texte coupé.
- [ ] Mobile : menu clair, cibles ≥ 44 px, claviers adaptés (tel, email, date), bouton d'action collant utile, tableaux admin lisibles (cartes).
- [ ] Ordinateur : vraie composition large (colonnes, grands visuels), largeurs de lecture maîtrisées.
- [ ] Orientation paysage, zoom 200 %, texte agrandi.

## Accessibilité
- [ ] axe-core sans violation sur chaque page ; navigation clavier complète ; focus visible ; labels ; contrastes AA ; `prefers-reduced-motion` ; textes alternatifs exacts ; ordre des titres.

## SEO / partage
- [ ] Title/description uniques, Open Graph + image, canonical, `sitemap.xml`, `robots.txt`, JSON-LD (LocalBusiness / Product / FAQ), 404, redirections, favicons, `lang`.

## Contenu
- [ ] Relecture de TOUS les textes selon references/anti-ia.md ; zéro lorem ipsum ; zéro donnée inventée ; coordonnées = celles fournies ; chaque image vérifiée par rapport à son sujet ; liens et boutons testés.

## Qualité du code
- [ ] `tsc --noEmit`, lint et build propres ; code mort supprimé ; composants factorisés ; erreurs gérées (états d'erreur visibles) ; tests de bout en bout des parcours clés (réservation/commande, connexion admin, création/modification d'un élément, formulaire de contact).

## Sortie
Écrire `qa/RAPPORT.md` : ce qui a été vérifié, mesuré (scores, captures), corrigé, et ce qui reste à surveiller.
